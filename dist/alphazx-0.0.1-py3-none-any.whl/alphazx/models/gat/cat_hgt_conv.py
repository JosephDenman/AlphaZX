import math
from typing import Optional, Dict, Union

import torch
from torch import Tensor
from torch_geometric.nn import HGTConv, Aggregation
from torch_geometric.typing import Adj, Metadata
from torch_geometric.utils import softmax

from alphazx.diagram.match import METADATA


class ConcatAggregation(Aggregation):
    def __init__(self):
        super(ConcatAggregation, self).__init__()

    def forward(
            self,
            x: Tensor,
            index: Optional[Tensor] = None,
            ptr: Optional[Tensor] = None,
            dim_size: Optional[int] = None,
            dim: int = 0,
            max_num_elements: Optional[int] = None,
    ) -> Tensor:
        return aggregate(x, index, max_num_elements)


class EdgeAttn(HGTConv):
    def edge_update(self) -> Tensor:
        pass

    def __init__(self,
                 in_channels: Union[int, Dict[str, int]],
                 out_channels: int,
                 metadata: Metadata,
                 heads: int = 1,
                 **kwargs):
        super(EdgeAttn, self).__init__(in_channels, out_channels, metadata, heads, **kwargs)

    def message_and_aggregate(self, adj_t: Adj) -> Tensor:
        pass

    def message(self, k_j: Tensor, q_i: Tensor, v_j: Tensor, edge_attr: Tensor,
                index: Tensor, ptr: Optional[Tensor],
                size_i: Optional[int]) -> Tensor:
        alpha = (q_i * k_j).sum(dim=-1) * edge_attr
        alpha = alpha / math.sqrt(q_i.size(-1))
        alpha = softmax(alpha, index, ptr, size_i)
        out = v_j * alpha.view(-1, self.heads, 1)
        return out.view(-1, self.out_channels)


hgt_conv = HGTConv(in_channels=10, out_channels=10, metadata=METADATA, heads=2)
