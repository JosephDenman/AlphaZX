import torch
import torch.nn as nn
import torch_geometric as pyg


class ValueNetwork(nn.Module):
    def __init__(self,
                 node_embedding_channels: int,
                 gmt_num_encoder_blocks: int,
                 gmt_num_heads: int,
                 gmt_layer_norm: bool,
                 gmt_dropout: float) -> None:
        super(ValueNetwork, self).__init__()
        self.pool = pyg.nn.GraphMultisetTransformer(node_embedding_channels, 1, gmt_num_encoder_blocks, gmt_num_heads,
                                                    gmt_layer_norm, gmt_dropout)
        self.mlp = pyg.nn.MLP([node_embedding_channels, 1])

    def forward(self, data: pyg.data.Data) -> torch.Tensor:
        x = self.pool(data.x, data.batch)
        res = self.mlp(x, data.batch)
        return res
